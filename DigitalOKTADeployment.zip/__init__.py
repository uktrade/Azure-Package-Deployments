import datetime
import logging
import os
import re
import requests
import json
import hashlib
import hmac
import base64

import azure.functions as func

from azure.identity import DefaultAzureCredential
from azure.monitor.ingestion import LogsIngestionClient
from azure.data.tables import TableServiceClient
from azure.data.tables import UpdateMode
from azure.core.exceptions import ResourceExistsError, ResourceNotFoundError


class DigitalOktaFunction():

    def __init__(self) -> None:
        #Azure Function State management between Executions 
        self.AzureWebJobsStorage = os.environ["AzureWebJobsStorage"]
        self.TableName = "OKTA"
        self.TotalRecordCount = 0

        #Variables needed for OKTA API Request
        self.APIToken = os.environ["apiToken"]
        self.baseUri = os.environ["uri"]
        self.StartDate = datetime.datetime.utcnow() - datetime.timedelta(days=2)
        self.logAnalyticsBaseUri = os.environ["logAnalyticsUri"]

        #Define the log analytics Workspace ID and Key and Custom Table name 
        self.customerID = os.environ["workspaceId"]
        self.sharedkey = os.environ["workspaceKey"]
        self.LogType = "OKTA"
        self.TimeStampField = "Published"
        self.resource = "/api/logs"

    

        #DCR Ingestion Vars
        self.dcr_id = os.environ['DCR_RULE_ID']
        self.endpoint = os.environ['DATA_COLLECTION_ENDPOINT']
        self.stream_name = os.environ['DCR_STREAM_NAME']
        self.credential = DefaultAzureCredential
        self.logging_client = LogsIngestionClient(endpoint=self.endpoint, credential=self.credential, logging_enable=True)

        
        #Get Storage Client
        self.storage_client = TableServiceClient.from_connection_string(conn_str=self.AzureWebJobsStorage, logging_enable=True)
        try:
            self.storage_table_client = self.storage_client.create_table(table_name=self.TableName)
            logging.info("Created table")
        except ResourceExistsError:
            self.storage_table_client = self.storage_client.get_table_client(table_name=self.TableName)


        self.logAnalyticsPattern = re.compile('https:\/\/([\w\-]+)\.ods\.opinsights\.azure\.([a-zA-Z\.]+)$')

    def buildSignature(self, customerID, sharedKey, date_d, contentLength, method, contentType, resource):
        x_headers = 'x-ms-date:' + date_d
        string_to_hash = method + "\n" + str(contentLength) + "\n" + contentType + "\n" + x_headers + "\n" + resource
        bytes_to_hash = bytes(string_to_hash, encoding="utf-8") 
        decoded_key = base64.b64decode(sharedKey)
        encoded_hash = base64.b64encode(hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()).decode()
        authorization = f"SharedKey {customerID}:{encoded_hash}"
        return authorization
    
    def retriveJobStorageRow(self):
        okta_time = self.StartDate.isoformat()

        try:
            row = self.storage_table_client.get_entity(partition_key="part1", row_key=self.APIToken)
            logging.info(row)
            if "uri" in row:
                return row['uri']
            else:
                uri = f"{self.baseUri}{okta_time}&limit=1000"
                self.createJobStorageRow(uri=uri)
                return uri
        except ResourceNotFoundError:
            uri = f"{self.baseUri}{okta_time}&limit=1000"
            self.createJobStorageRow(uri=uri)
            return uri
    
    def createJobStorageRow(self, uri):
        entity = {
                u'PartitionKey': 'part1',
                u'RowKey': self.APIToken,
                u'uri': uri
            }
        try:
            self.storage_table_client.create_entity(entity=entity)
        except ResourceExistsError:
            row = self.storage_table_client.get_entity(partition_key="part1", row_key=self.APIToken)
            self.storage_table_client.update_entity(mode=UpdateMode.REPLACE,entity=row)

    def run(self, utc_timestamp):
        if self.logAnalyticsBaseUri is None or self.logAnalyticsBaseUri == "":
            self.logAnalyticsBaseUri = f"https://{self.customerID}/ods.opinsights.azure.com"

        if not self.logAnalyticsPattern.match(self.logAnalyticsBaseUri):
            logging.critical(f"Log Analytic Workspace URI does not match pattern, logAnalyticsBaseUri: {self.logAnalyticsBaseUri}")
            raise Exception ("logAnalyticsBaseUri Does not match format")

        # logAnalyticsUri = self.logAnalyticsBaseUri + self.resource + "?api-version=2016-04-01"
        uri = self.retriveJobStorageRow()

        #setup URI headers for request to OKTA
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "AzureFunction",
            "Authorization": f"SSWS {self.APIToken}",
            "Accept-Encoding": "gzip, br"
        }

        okta_exit_flag = True
        TotalRecordCount = 0
        while(okta_exit_flag):
            uriself = uri
            if len(uri) > 0:
                logging.info(f"Sending request to OKTA API endpoint {uri}")
                resp = requests.get(url=uri, headers=headers)
                logging.info(f"OKTA responded, Status Code: {resp.status_code}")
                if resp.status_code != 200:
                    logging.info(resp.text)
                else:
                    respJSON = resp.json()
                    # with open('log.json', 'w') as f:
                    #     json.dump(respJSON, f)

            if "link" in resp.headers:
                logging.info(resp.headers)
                logging.info(type(resp.headers['link']))
                
                link_string = resp.headers["link"].split(",")
                if link_string[0].split(';')[1] == ' rel="self"' and link_string[1].split(';')[1] == ' rel="next"':
                    uri = link_string[1].split(';')[0].replace("<", "").replace(">", "").replace(" ", "")
                    logging.info(f"Re-created URI from headers from endpoint {uri}")
                else:
                    logging.info(f"link header returned a unexpected format, {link_string}")
            else:
                logging.info(f"Exiting loop, no link returned in headers \n Headers: {resp.headers}")
                okta_exit_flag = False

            if uri != uriself:
                respCount = len(respJSON)
                TotalRecordCount = TotalRecordCount + respCount

                # #ACN_CD_OKTAISSUE925
                # pattern = re.compile("https:\/\/([\w\.\-]+)\/")
                # domain = pattern.match(uri).group(1)
                # # respJSON.update({"domain": domain})
                # method = "POST"
                # contentType = "application/json"
                # rfc1123date = datetime.datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')

                # body = json.dumps(respJSON).encode('utf-8')
                # contentLength = len(body)
                # signature = self.buildSignature(customerID=self.customerID, sharedKey=self.sharedkey, date_d=rfc1123date, contentLength=contentLength, method=method, contentType=contentType, resource=self.resource)

                # LAheadres = {
                #     "Authorization": signature,
                #     "Log-Type": self.LogType,
                #     "x-ms-date": rfc1123date,
                #     "time-generated-field": self.TimeStampField
                # }

                # result = requests.post(url=logAnalyticsUri, headers=LAheadres, data=body)
                # logging.info(f"Logs shipped to LA, Status Code: {result.status_code}")

                self.logging_client.upload(rule_id=self.dcr_id, stream_name=self.stream_name, logs=respJSON)

                self.createJobStorageRow(uri=uri)
            else:
                logging.info(f"URI and previous URI are equal, existing loop {uri}")
                okta_exit_flag = False
            if((datetime.datetime.utcnow() - utc_timestamp).seconds > 500):
                logging.info("Logs up to date, exiting loop")
                okta_exit_flag = False
        
        if TotalRecordCount < 1:
            logging.info(f"OKTASSO: No new OKTA logs since {self.StartDate} are available at {utc_timestamp}")
        else:
            logging.info(f"OKTASSO: {TotalRecordCount} retrived from OKTA between {self.StartDate} and {utc_timestamp}")
        
        finish_time = datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
        logging.info(f"OKTASSO: Completeded execution: Start Time: {self.StartDate},  End time: {finish_time}, Processed Records: {TotalRecordCount}")


def main(mytimer: func.TimerRequest) -> None:
    
    utc_timestamp = datetime.datetime.utcnow()

    if mytimer.past_due:
        logging.info('The timer is past due!')

    logging.info('Python timer trigger function ran at %s', utc_timestamp)

    okta = DigitalOktaFunction()
    okta.run(utc_timestamp=utc_timestamp)  