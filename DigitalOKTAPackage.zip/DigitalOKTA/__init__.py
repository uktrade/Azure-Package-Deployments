import datetime
import logging
import os
import re
import requests
import json
import hashlib
import hmac
import base64

import azure.functions as func

from datetime import datetime
from  azure.data.tables import TableServiceClient
from azure.core.exceptions import ResourceExistsError

#Azure Function State management between Executions 
AzureWebJobsStorage = os.environ["AzureWebJobsStorage"]
TableName = "OKTA"
TotalRecordCount = 0

#Variables needed for OKTA API Request
APIToken = os.environ["apiToken"]
baseUri = os.environ["uri"]
StartDate = datetime.utcnow()
logAnalyticsBaseUri = os.environ["logAnalyticsUri"]

#Define the log analytics Workspace ID and Key and Custom Table name 
customerID = os.environ["workspaceId"]
sharedkey = os.environ["workspaceKey"]
LogType = "OKTA"
TimeStampField = "Published"
resource = "/api/logs"

logAnalyticsPattern = re.compile('https:\/\/([\w\-]+)\.ods\.opinsights\.azure\.([a-zA-Z\.]+)$')

def buildSignature(customerID, sharedKey, date_d, contentLength, method, contentType, resource):
    x_headers = 'x-ms-date:' + date_d
    string_to_hash = method + "\n" + str(contentLength) + "\n" + contentType + "\n" + x_headers + "\n" + resource
    bytes_to_hash = bytes(string_to_hash, encoding="utf-8") 
    decoded_key = base64.b64decode(sharedKey)
    encoded_hash = base64.b64encode(hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()).decode()
    authorization = f"SharedKey {customerID}:{encoded_hash}"
    return authorization

def retriveJobStorageRow():
    storage_client = TableServiceClient.from_connection_string(conn_str=AzureWebJobsStorage)
    try:
        storage_table_client = storage_client.create_table(table_name=TableName)
        logging.info("Created table")
        createJobStorageRow(uri=f"{baseUri}{StartDate}&limit=1000")
    except ResourceExistsError:
        storage_table_client = storage_client.get_table_client(table_name=TableName)

    row = storage_table_client.get_entity(partition_key="part1", row_key=APIToken)
    if row.uri is None:
        createJobStorageRow(uri=f"{baseUri}{StartDate}&limit=1000")
    return row.uri 

def createJobStorageRow(uri):
    storage_client = TableServiceClient.from_connection_string(conn_str=AzureWebJobsStorage)
    storage_table_client = storage_client.get_table_client(table_name=TableName)
    entity = {
            u'PartitionKey': 'part1',
            u'RowKey': APIToken,
            u'uri': uri
        }
    storage_table_client.create_entity(entity=entity)

def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()

    if mytimer.past_due:
        logging.info('The timer is past due!')

    logging.info('Python timer trigger function ran at %s', utc_timestamp)

    if logAnalyticsBaseUri is None or logAnalyticsBaseUri == "":
        logAnalyticsBaseUri = f"https://{customerID}/ods.opinsights.azure.com"

    if not logAnalyticsPattern.match(logAnalyticsBaseUri):
        logging.critical(f"Log Analytic Workspace URI does not match pattern, logAnalyticsBaseUri: {logAnalyticsBaseUri}")
        raise Exception ("logAnalyticsBaseUri Does not match format")

    logAnalyticsUri = logAnalyticsBaseUri + resource + "?api-version=2016-04-01"

    uri = retriveJobStorageRow()

    #setup URI headers for request to OKTA
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "AzureFunction",
        "Authorization": f"SSWS {APIToken}",
        "Accept-Encoding": "gzip, br"
    }

    okta_exit_flag = True
    while(okta_exit_flag):
        uriself = uri
        if uri.length() > 0:
            logging.debug(f"Sending request to OKTA API endpoint {uri}")
            resp = requests.get(url=uri, body=None, headers=headers)
            logging.debug(f"OKTA responded, Status Code: {resp.status_code}")

        if "link" in resp.headers:
            uritmp = resp.headers["link"].split(",;")
            uritmp = uritmp.split(';')
            uri = uritmp[2].replace("<|>", "")
            logging.debug(f"Re-created URI from headers from endpoint {uri}")
        else:
            logging.debug(f"Exiting loop, no link returned in headers \n Headers: {resp.headers}")
            okta_exit_flag = False

        if uri != uriself:
            respJSON = resp.json()
            respCount = respJSON.count
            TotalRecordCount = TotalRecordCount + respCount

            #ACN_CD_OKTAISSUE925
            pattern = re.compile("https:\/\/([\w\.\-]+)\/")
            domain = pattern.match(uri).group(1)
            respJSON.update({"domain": domain})
            method = "POST"
            contentType = "application/json"
            rfc1123date = datetime.datetime.utcnow().strftime('%a, %d %b %Y %H:%M:%S GMT')
            
            body = json.dumps(respJSON).encode('utf-8')
            contentLength = len(body)
            signature = buildSignature(customerID=customerID, sharedKey=sharedkey, date_d=rfc1123date, contentLength=contentLength, method=method, contentType=contentType, resource=resource)

            LAheadres = {
                "Authorization": signature,
                "Log-Type": LogType,
                "x-ms-date": rfc1123date,
                "time-generated-field": TimeStampField
            }

            result = requests.post(url=logAnalyticsUri, headers=LAheadres, data=body)
            logging.debug(f"Logs shipped to LA, Status Code: {result.status_code}")

            createJobStorageRow(uri=uri)
        else:
            logging.debug(f"URI and previous URI are equal, existing loop {uri}")
            okta_exit_flag = False
        if((datetime.fromisoformat(utc_timestamp) - datetime.utcnow()).seconds > 500):
            logging.info("Logs up to date, exiting loop")
            okta_exit_flag = False
    
    if TotalRecordCount < 1:
        logging.info(f"OKTASSO: No new OKTA logs since {StartDate} are available at {utc_timestamp}")
    else:
        logging.info(f"OKTASSO: {TotalRecordCount} retrived from OKTA between {StartDate} and {utc_timestamp}")
    
    finish_time = datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
    logging.info(f"OKTASSO: Completeded execution: Start Time: {StartDate},  End time: {finish_time}, Processed Records: {TotalRecordCount}")

            

